export const API={
    BASE_URL : "https://jsonplaceholder.typicode.com",
    GET_POSTS : "/posts"
}