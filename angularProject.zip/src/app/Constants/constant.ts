export const CONSTANTS = {
    COLUMN_NAME: ['Id', 'UserId', 'Title', 'Body'],
    POST_DETAIL : "Post Detail",
    LOADING : "Please Wait Loading...",
    ID:'Id',
    USERID : 'UserId',
    TITLE: 'Title',
    BODY : 'Body',
    HEADER : 'Angular Assignment',
    FOOTER : 'footer'
}